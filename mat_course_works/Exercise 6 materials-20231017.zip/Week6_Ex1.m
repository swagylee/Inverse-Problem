%%% Inverse Problems 1 - 2022
%%% Week 6 - Exercise 1

%%% DON'T REMOVE THESE! OTHERWISE YOU RUN THE RISK OF USING VARIABLES WHICH
%%% ARE NOT DEFINED IN THE CODE.
clear all
close all

%% %%% Task: Load data stored in 'W6_Ex1.mat', then
%%% (optional but recommended) utilize fftshift in b)-d)
%%% a) Plot the time-series data 'd' in figure 1 with appropriate titles etc.
%%% 
%%% b) Compute the FFT of 'd' and plot the real component and imaginary component 
%%% in figure 2 (with appropriate titles etc.).
%%% 
%%% c) Plot the magnitude of the FFT in figure 3.
%%% 
%%% d) Plot the phase of the FFT in figure 4 (it is recommended to only plot
%%% frequencies which are meaningful (magnitude > 10 for example).

%%% The following code will get you started but feel free to change it as
%%% long as it runs!

%%% Load .mat file
load('W6_Ex1.mat')

% Length of our data (number of samples)
L = length(d);

%%% a) Make a fancy d(x)-plot here
figure(1);
plot(x,d);

% D = ... FFT of 'd' goes here

%%% b) Plot real part of D using plot or bar for example.
figure(2);
% ...

%%% Include also the imaginary part in the same plot. For that, use
%%% 'hold on'. This allows you to add to an existing figure. When you are
%%% done it's best to do 'hold off' just in case.

%%% Example:
%%% figure;
%%% plot(t,g,'r') % g(t) in red
%%% hold on % (to your plots!)
%%% plot(z,h,'b') % h(z) in blue in the same plot
%%% hold off % This is not necessary but leaving it out may cause problems.

%%% c) Plot the magnitude of the FFT coefficients.
figure(3);

%%% Plot the phase angle of the FFT coefficients. The function 'angle'
%%% might be useful. Also consider only plotting those frequencies which
%%% are "meaningful".

figure(4);
% Scatterplot is a good choice here but feel free to try different things
% scatter(...)

% These might be helpful to adjust the y ticks.
ylim = [-pi,pi];
yticks(pi*linspace(-1,1,5))
yticklabels({'-\pi', '-\pi/2', 0, '\pi/2', '\pi'})
