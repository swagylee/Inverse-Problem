%%% Inverse Problems 1 - 2022
%%% Week 6 - Exercise 4

%%% DON'T REMOVE THESE! OTHERWISE YOU RUN THE RISK OF USING VARIABLES WHICH
%%% ARE NOT DEFINED IN THE CODE.
clear all
close all

%% Trying out naive FFT deconvolution
%%% a) Create a sawtooth function of length L = 128 and visualize it.

L = 128;

%%% Note: Matlab has built-in sawtooth function with period of 2pi.  

%%% b) Create Gaussian convolution kernel (in the spatial domain) and use
%%% it to smooth the original signal (keep it length L). Plot the smoothed
%%% version as well.

%%% Note: Normalizing the gaussian makes life easier

%%% c) Try deconvolution by computing the (length L) FFT of the PSF and
%%% then pointwise divide the FFT of the smooth signal by the FFT of the PSF,
%%% IFFT and see if you can get the original function (or something similar) back.
